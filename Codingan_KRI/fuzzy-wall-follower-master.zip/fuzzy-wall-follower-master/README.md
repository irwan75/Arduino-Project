Fuzzy wall-follower
==================
a fuzzy controller for a wall follower robot made ​​with Arduino library eFLL 

##eFLL documentation:
http://zerokol.com/post/51e9324ee84c55a1f5000007/1/en

##eFLL github:
https://github.com/zerokol/eFLL

##main components of the robot: 
1 due arduino

2 dc motors

1 ci L293D to control motors

2 HC-SR04 ultrasonic sensors

